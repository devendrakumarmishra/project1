(function($) {
  Drupal.behaviors.stu_forms = {
    attach: function (context, settings) {
      $("#edit-field-treatment-type-und input[name=field_treatment_type[und]]:radio").click(function () {
        var action = $(this).val();
        window.location.href = Drupal.settings.basePath + 'node/add/surgeon/' + action.toLowerCase();
        $('input:radio[value='+action+']').attr('checked', true);
      });
    }
  };
})(jQuery);
